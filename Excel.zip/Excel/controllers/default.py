# -*- coding: utf-8 -*-
import sys,subprocess,os,sqlite3,exceptions,zipfile
# this file is released under public domain and you can use without limitations
#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################


def validNameExcel(nameOfFile):
    if(" " in nameOfFile):
        return False

    for name in nameOfFile.split('.'):
        for word in name.split('_'):
            for letter in word:
                if not letter.isalpha():
                    return False
    return True

#Test if the name only contains letters(ascii) and numbers (with '_' possibly)
#I:A name
#O:True or False
def validNameImage(nameOfFile):
    if(" " in nameOfFile):
        return False

    for name in nameOfFile.split('.'):
        for word in name.split('_'):
            for letter in word:
                if not letter.isalpha() and not letter.isdigit():
                    return False
    return True

#Unzip file to static/UploadedImages/
#I:path of file, form
#O: None
def testzip(fileZip):
    db = DAL('sqlite://storage.sqlite',auto_import=True)
    UploadedImages=db.UploadedImages
    pathToFolder = ""
    if os.name=="nt":
        pathToFolder = 'static\\UploadedImages' ##not saved by web2py in db.py
    else:
        pathToFolder = 'static/UploadedImages' ##not saved by web2py in db.py
    UploadedImages['Image'].uploadfolder = os.path.join(request.folder.decode("latin-1"),'static\\UploadedImages')
    url = URL('download')
    with(zipfile.ZipFile(fileZip.file)) as zf:
        for file in zf.infolist():
            if file.filename.endswith('.png') or file.filename.endswith('.jpg'):
                if validNameImage(file.filename):
                    if len(db(file.filename==db.UploadedImages.imageoname).select()) == 0:
                        if os.name == "nt":
                            zf.extract(file,os.path.join(request.folder.decode("latin-1"),pathToFolder))
                            pathRequest = os.path.join(request.folder.decode("latin-1"),pathToFolder+'\\'+file.filename)
                        else:
                            zf.extract(file,os.path.join(request.folder.decode("utf-8"),pathToFolder))
                            pathRequest = os.path.join(request.folder.decode("utf-8"),pathToFolder+'/'+file.filename)
                        request.vars = None
                        contentFile = ""
                        with open(pathRequest,"rb") as f:
                            contentFile = f.read()
                        request.vars.Image = contentFile
                        request.vars.imageoname = file.filename
                        url = URL('download')
                        form = SQLFORM(UploadedImages,deletable=True,upload=url,formname="inszip")
                        form.accepts(request.vars,session=None)
                        #file is uploaded as txt so we have to change its extension in both db and system
                        db(db.UploadedImages.imageoname==str(file.filename)).update(Image=form.vars.Image.replace('.txt','.'+str(file.filename).split('.')[1]))
                        try:
                            if os.name=="nt":
                                oldFile = os.path.join(request.folder,pathToFolder+'\\'+str(file.filename))
                                obsoleteName = os.path.join(request.folder,pathToFolder+'\\'+form.vars.Image)
                                imageName = form.vars.Image.replace('.txt','.'+str(file.filename).split('.')[1])
                                subprocess.check_call(["ren",obsoleteName,imageName],shell=True)
                                subprocess.check_call(["DEL","/Q",oldFile],shell=True)
                            else:
                                oldFile = os.path.join(request.folder,pathToFolder+'/'+file.filename)
                                obsoleteName = os.path.join(request.folder,pathToFolder+'/'+form.vars.Image)
                                imageName = os.path.join(request.folder,pathToFolder+'/'+form.vars.Image.replace('.txt','.'+file.filename.split('.')[1]))
                                subprocess.check_call(["mv",oldFile,imageName])
                                #subprocess.check_call(["rm","-f",oldFile])
                        except subprocess.CalledProcessError as er:
                            print er.message
                    else:
                        session.messageErrorI+="File already in database "+file.filename
                else:
                    session.messageErrorI+="Wrong name "+file.filename
            else:
                session.messageErrorI+="Wrong format "+file.filename
    db.close()


#Delete file from uploads and undo insert into db.excel
#I:name file and name file after upload
#O:None
def deleteUploadedFile(oldName,newName):
    #remove from excel
    db = DAL('sqlite://storage.sqlite',auto_import=True)
    db(db.excel.fileoname == oldName).delete()
    db.close()
    #remove from uploads
    path=os.path.abspath(os.path.dirname(__file__))
    filePath=path+"/../uploads/"+newName
    try:
        if os.name=="nt":
            subprocess.check_call(["DEL","/Q",filePath.replace('/','\\')],shell=True)
        else:
            subprocess.check_call(["rm","-f",filePath])     
    except subprocess.CalledProcessError as er:
        print er.message

def deleteUploadedImage(oldName,newName):
    #remove from uploadedImages
    db = DAL('sqlite://storage.sqlite',auto_import=True)
    db(db.UploadedImages.imageoname == oldName).delete()
    #remove from static/UploadedImages
    path=os.path.abspath(os.path.dirname(__file__))
    filePath=path+"/../static/UploadedImages/"+newName
    try:
        if os.name=="nt":
            subprocess.check_call(["DEL","/Q",filePath.replace('/','\\')],shell=True)
        else:
            subprocess.check_call(["rm","-f",filePath])     
    except subprocess.CalledProcessError as er:
        print er.message
        
        
#Generate a form that will upload a file.
#Test if this file's name is already into db.excel
#Test if excel2web2py folder exists
#Execute script.py with the uploaded file
#Test if errors happened
#Execute the new generated db_Model to generate tables
#Execute scriptInit.py with the uploaded file
#Display appropriate message in flash
#form.process() cannot be avoided in any case because it generates a formkey that is important for the view
#I:None
#O:None
#controller is called twice so it is written according to this event
def excel():
    db = DAL('sqlite://storage.sqlite',auto_import=True)
    excel=db.excel
    url = URL('download')
    form = SQLFORM(excel,deletable=True,
    upload=url, fields=['file'])

    if ((request.vars.file != "") and (request.vars.file != None)):
        form.vars.fileoname = request.vars.file.filename

    res=False
    try:
        res=form.process().accepted
        db.close()
    except (sqlite3.IntegrityError,exceptions.ValueError) as er:
        if er.message == "column fileoname is not unique":
            session.messageError = "form has errors, rename the file or check the readme"
        elif "may not be NULL" in er.message:
            session.messageError = "No file selected"
        else:
            session.messageError = er.message
            
        if len(db(excel.fileoname == form.vars.fileoname).select()) != 0 :
            db.close()
            deleteUploadedFile(form.vars.fileoname,form.vars.file)
        else:
            db.close()
        res=False
	db.close()	
    if((form.vars.fileoname is "")or(form.vars.fileoname is None)):
        if response.flash is not "":
            session.messageError = 'No file selected'
    elif(not form.vars.fileoname.endswith(".xlsx") and not form.vars.fileoname.endswith(".xls") ):
        session.messageError = 'Select a Excel file (.xlsx or .xls)'
        oldName = form.vars.fileoname
        newName = form.vars.file
        if newName is not None:
           deleteUploadedFile(oldName,newName)
    elif not validNameExcel(request.vars.file.filename):
        session.messageError = 'No special characters, accents inclued'
        oldName = form.vars.fileoname
        newName = form.vars.file
        if newName is not None:
           deleteUploadedFile(oldName,newName)		
    elif res:
        oldName = form.vars.fileoname
        newName = form.vars.file #important when a file is uploaded, he takes a new name, this is it
        path=os.path.abspath(os.path.dirname(__file__))
        if os.name=="nt":
              filePath=path+"\\..\\uploads\\"+newName
        else:
            filePath=path+"/../uploads/"+newName
        listFolders=[f for f in os.listdir(path+'/../') if os.path.isdir(path+'/../'+f)] 		
        nameFolderScript=""
        for f in listFolders:
            if "excel2web2py" in f:
                nameFolderScript=f
        if nameFolderScript == "":
            print "No excel2web2py folder"            session.messageError = "500 : internal error"
            redirect(URL('default','excel'))
        elif os.path.isfile(filePath):
            from subprocess import check_call
            cmd = []
            output = ""
            if os.name=="nt":
                cmd = ["python",path+"\\..\\"+nameFolderScript+"\\script.py",filePath,oldName]
                output = subprocess.Popen(cmd,stderr=subprocess.PIPE,shell=True)
            else:
                cmd = ["python",path+"/../"+nameFolderScript+"/script.py",filePath,oldName]   
                output = subprocess.Popen(cmd,stderr=subprocess.PIPE)
            msg=output.stderr.read()
            #false error sometimes so I added a tag to determine what errors are from script
            if msg != "" and "Error:" in msg :
                    session.messageError = msg
                    deleteUploadedFile(oldName,newName)
                    redirect(URL('default','excel'))
            try:
                #defineTables should have been written in the new model, let's call it
                dbCode = open(path+'/../models/db_'+oldName.split('.')[0]+'.py').read()
                exec dbCode
            except exceptions.IOError as er:
                print er.message
                deleteUploadedFile(oldName,newName)
                session.messageError = er.message
                redirect(URL('default','excel'))
            #Tables have been created, let's fill them all
            try:
                if os.name=="nt":
                    subprocess.check_call(["python",path+'\\..\\'+nameFolderScript+'\\scriptInit.py',filePath],shell=True)
                else:
                    subprocess.check_call(["python",path+'/../'+nameFolderScript+'/scriptInit.py',filePath])
            except subprocess.CalledProcessError as er:
                print er.message
                session.messageError = er.message
                deleteUploadedFile(oldName,newName)
                
        #refresh page and menu
        session.messageError = 'form accepted'
        response.flash = session.messageError
        redirect(URL('default','excel'))
    else:
        response.flash = "form has errors, rename the file or check the readme"
        
    response.flash = session.messageError

    return dict(form=form)
    
#Upload image
def picture():
    db = DAL('sqlite://storage.sqlite',auto_import=True)
    UploadedImages=db.UploadedImages
    if os.name=="nt":
        UploadedImages['Image'].uploadfolder  = os.path.join(request.folder.decode("latin-1"),'static\\UploadedImages') ##not saved by web2py in db.py
    else:
        UploadedImages['Image'].uploadfolder  = os.path.join(request.folder,'static/UploadedImages') ##not saved by web2py in db.py
    url = URL('download')
    form = SQLFORM(UploadedImages,deletable=True,
    upload=url,fields=['Image'])
    if ((request.vars.Image != "") and (request.vars.Image != None)):
        form.vars.imageoname = request.vars.Image.filename

    res=False
    try:
        res=form.process().accepted
        db.close()
    except (sqlite3.IntegrityError,exceptions.ValueError) as er:
        if er.message == "column imageoname is not unique":
            session.messageErrorI = "form has errors, rename the file or check the readme"
        elif "may not be NULL" in er.message:
            session.messageErrorI = "No file selected"
        else:
            session.messageErrorI = er.message
        if len(db(UploadedImages.imageoname == form.vars.imageoname).select()) != 0 :
            db.close()
            deleteUploadedImage(form.vars.imageoname,form.vars.Image)
        else:
            db.close()
        res=False    
    if((form.vars.imageoname is "")or(form.vars.imageoname is None)):
        if response.flash is not "":
            session.messageErrorI = 'No file selected'
    elif(not form.vars.imageoname.endswith(".png") and not form.vars.imageoname.endswith(".jpg") and not form.vars.imageoname.endswith(".zip")):
        session.messageErrorI = 'Select a Picture file (.png or .jpg) or an archive (.zip)'
        oldName = form.vars.imageoname
        newName = form.vars.Image
        if newName is not None:
           deleteUploadedImage(oldName,newName)
    elif not validNameImage(request.vars.Image.filename):
        session.messageErrorI = "name of file is not conformed: only letters (no accents),numbers and '_' are allowed"
        oldName = form.vars.imageoname
        newName = form.vars.Image
        deleteUploadedImage(oldName,newName)
    elif res:
        oldName = form.vars.imageoname
        newName = form.vars.Image
        session.messageErrorI = 'form accepted'
        if request.vars.Image.filename.endswith(".zip"):
            testzip(request.vars.Image)
            deleteUploadedImage(oldName,newName)
    else:
        response.flash = "form has errors, rename the file or check the readme"
        
    response.flash = session.messageErrorI

    return dict(form=form)

def index():  
    return response.render()

def readme():
    return response.render()

def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    print request
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
def forming(table):
    form = SQLFORM(table)
    if form.process().accepted:
        response.falsh = 'form accepted'
    elif form.errors:
        response.flash = 'form has errors'
    return form
