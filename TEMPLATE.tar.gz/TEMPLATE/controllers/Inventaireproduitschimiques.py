# -*- coding: utf-8 -*-
import sys,subprocess,matplotlib.pyplot as plt
# this file is released under public domain and you can use without limitations
#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

#requires login


def index():
    return response.render()


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
def forming(table):
    form = SQLFORM(table)
    if form.process().accepted:
        response.flash = 'form accepted'
    elif form.errors:
        response.flash = 'form has errors'
    return form


def booInventaireproduitschimiques0(value,row,db):
    listOfRefs = []
    listAttr=[]
    rowvals = row.Mentions_de_danger.split("|")
    for val in rowvals :
        res=db(db["Mentions_de_danger"].id == val).select()
        listValAttr=[]
        for row in res:
            for attr in row:
                if attr != "id":
                    if ((type(row[attr]) is str) or (type(row[attr]) is int) or (type(row[attr]) is float)):
                        if attr not in listAttr:
                            listAttr.append(attr)
                        listValAttr.append(row[attr])
        listOfRefs.append(listValAttr)
    listOfRefs.insert(0,listAttr)
    t=["w2p_odd odd","w2p_even even"]
    return TABLE(*[TR(r, _class=t[idx%2]) for idx,r in enumerate(listOfRefs)])
def booInventaireproduitschimiques1(value,row,db):
    listOfRefs = []
    listAttr=[]
    rowvals = row.Conseils_de_prudence.split("|")
    for val in rowvals :
        res=db(db["Conseils_de_prudence"].id == val).select()
        listValAttr=[]
        for row in res:
            for attr in row:
                if attr != "id":
                    if ((type(row[attr]) is str) or (type(row[attr]) is int) or (type(row[attr]) is float)):
                        if attr not in listAttr:
                            listAttr.append(attr)
                        listValAttr.append(row[attr])
        listOfRefs.append(listValAttr)
    listOfRefs.insert(0,listAttr)
    t=["w2p_odd odd","w2p_even even"]
    return TABLE(*[TR(r, _class=t[idx%2]) for idx,r in enumerate(listOfRefs)])
def Produits_chimiques():
    db = getDb()
    table = db.Produits_chimiques
    db.Produits_chimiques.Mentions_de_danger.represent = lambda val,row:booInventaireproduitschimiques0(val,row,db)
    db.Produits_chimiques.Conseils_de_prudence.represent = lambda val,row:booInventaireproduitschimiques1(val,row,db)
    rows = db(table).select()
    if (len(rows) == 0):
        initData()
    rows = db(table).select()
    form = FORM(DIV(LABEL('Masse_molaire_gmol'),INPUT(_name='Masse_molaire_gmol',_type='checkbox'),_class='row'),DIV(LABEL('Masse_molaire_gmoli'),INPUT(_name='Masse_molaire_gmoli',_type='checkbox'),_class='row'),DIV(LABEL('Simple plot'),INPUT(_type='radio',_name='plot',_value='plot' ,value='plot'),LABEL('Histogram'),INPUT(_type='radio',_name='plot',_value='hist'),LABEL('Subplots'),INPUT(_type='radio',_name='plot',_value='sub'),_class='row'),INPUT(_type='submit',_class='btn btn-primary',_name='makeplot'),_class='form-horizontal',_action='',_method='post')
    plot=DIV('')
    if ((len(request.post_vars)>2) and ("makeplot" in request.post_vars)):
        vars = request.post_vars.keys()
        vars.remove('makeplot')
        s=""
        typeplot=''
        for v in vars :
            if v == 'plot' :
                typeplot = request.post_vars.plot
            else :
                s+=str(v)+','
        s=s[:-1]
        if typeplot == 'hist' :
            plt.hist(db.executesql("Select "+s+" from Produits_chimiques"))
            plt.xlabel('Value')
            plt.ylabel('Number')
        elif typeplot == 'sub' :
            for idx,item in enumerate(s.split(',')) :
                plt.subplot(len(s.split(',')),1,idx+1)
                plt.plot(db.executesql("Select "+item+" from Produits_chimiques"))
                plt.ylabel(item+' (Value)')
            plt.xlabel('Number')
        else :
            plt.xlabel('Number')
            plt.ylabel('Value')
            plt.plot(db.executesql("Select "+s+" from Produits_chimiques"))
        plt.title('Plot of Produits_chimiques with '+s)
        plt.savefig('applications/TEMPLATE/static/foo.png')
        plt.clf()
        plot=IMG(_src=URL('static','foo.png'),_alt='plot')
    records=SQLFORM.grid(table,paginate=10,maxtextlength=256,showbuttontext=False)
    return dict(form=form, plot=plot, records=records)
def Mentions_de_danger():
    db = getDb()
    table = db.Mentions_de_danger
    db.Produits_chimiques.Mentions_de_danger.represent = lambda val,row:booInventaireproduitschimiques0(val,row,db)
    rows = db(table).select()
    if (len(rows) == 0):
        initData()
    rows = db(table).select()
    form = FORM(DIV(LABEL('Simple plot'),INPUT(_type='radio',_name='plot',_value='plot' ,value='plot'),LABEL('Histogram'),INPUT(_type='radio',_name='plot',_value='hist'),LABEL('Subplots'),INPUT(_type='radio',_name='plot',_value='sub'),_class='row'),INPUT(_type='submit',_class='btn btn-primary',_name='makeplot'),_class='form-horizontal',_action='',_method='post')
    plot=DIV('')
    if ((len(request.post_vars)>2) and ("makeplot" in request.post_vars)):
        vars = request.post_vars.keys()
        vars.remove('makeplot')
        s=""
        typeplot=''
        for v in vars :
            if v == 'plot' :
                typeplot = request.post_vars.plot
            else :
                s+=str(v)+','
        s=s[:-1]
        if typeplot == 'hist' :
            plt.hist(db.executesql("Select "+s+" from Mentions_de_danger"))
            plt.xlabel('Value')
            plt.ylabel('Number')
        elif typeplot == 'sub' :
            for idx,item in enumerate(s.split(',')) :
                plt.subplot(len(s.split(',')),1,idx+1)
                plt.plot(db.executesql("Select "+item+" from Mentions_de_danger"))
                plt.ylabel(item+' (Value)')
            plt.xlabel('Number')
        else :
            plt.xlabel('Number')
            plt.ylabel('Value')
            plt.plot(db.executesql("Select "+s+" from Mentions_de_danger"))
        plt.title('Plot of Mentions_de_danger with '+s)
        plt.savefig('applications/TEMPLATE/static/foo.png')
        plt.clf()
        plot=IMG(_src=URL('static','foo.png'),_alt='plot')
    records=SQLFORM.grid(table,paginate=10,maxtextlength=256,showbuttontext=False)
    return dict(form=form, plot=plot, records=records)
def Conseils_de_prudence():
    db = getDb()
    table = db.Conseils_de_prudence
    db.Produits_chimiques.Conseils_de_prudence.represent = lambda val,row:booInventaireproduitschimiques1(val,row,db)
    rows = db(table).select()
    if (len(rows) == 0):
        initData()
    rows = db(table).select()
    form = FORM(DIV(LABEL('Simple plot'),INPUT(_type='radio',_name='plot',_value='plot' ,value='plot'),LABEL('Histogram'),INPUT(_type='radio',_name='plot',_value='hist'),LABEL('Subplots'),INPUT(_type='radio',_name='plot',_value='sub'),_class='row'),INPUT(_type='submit',_class='btn btn-primary',_name='makeplot'),_class='form-horizontal',_action='',_method='post')
    plot=DIV('')
    if ((len(request.post_vars)>2) and ("makeplot" in request.post_vars)):
        vars = request.post_vars.keys()
        vars.remove('makeplot')
        s=""
        typeplot=''
        for v in vars :
            if v == 'plot' :
                typeplot = request.post_vars.plot
            else :
                s+=str(v)+','
        s=s[:-1]
        if typeplot == 'hist' :
            plt.hist(db.executesql("Select "+s+" from Conseils_de_prudence"))
            plt.xlabel('Value')
            plt.ylabel('Number')
        elif typeplot == 'sub' :
            for idx,item in enumerate(s.split(',')) :
                plt.subplot(len(s.split(',')),1,idx+1)
                plt.plot(db.executesql("Select "+item+" from Conseils_de_prudence"))
                plt.ylabel(item+' (Value)')
            plt.xlabel('Number')
        else :
            plt.xlabel('Number')
            plt.ylabel('Value')
            plt.plot(db.executesql("Select "+s+" from Conseils_de_prudence"))
        plt.title('Plot of Conseils_de_prudence with '+s)
        plt.savefig('applications/TEMPLATE/static/foo.png')
        plt.clf()
        plot=IMG(_src=URL('static','foo.png'),_alt='plot')
    records=SQLFORM.grid(table,paginate=10,maxtextlength=256,showbuttontext=False)
    return dict(form=form, plot=plot, records=records)
def Link():
    db = getDb()
    table = db.Link
    rows = db(table).select()
    if (len(rows) == 0):
        initData()
    rows = db(table).select()
    form = FORM(DIV(LABEL('Simple plot'),INPUT(_type='radio',_name='plot',_value='plot' ,value='plot'),LABEL('Histogram'),INPUT(_type='radio',_name='plot',_value='hist'),LABEL('Subplots'),INPUT(_type='radio',_name='plot',_value='sub'),_class='row'),INPUT(_type='submit',_class='btn btn-primary',_name='makeplot'),_class='form-horizontal',_action='',_method='post')
    plot=DIV('')
    if ((len(request.post_vars)>2) and ("makeplot" in request.post_vars)):
        vars = request.post_vars.keys()
        vars.remove('makeplot')
        s=""
        typeplot=''
        for v in vars :
            if v == 'plot' :
                typeplot = request.post_vars.plot
            else :
                s+=str(v)+','
        s=s[:-1]
        if typeplot == 'hist' :
            plt.hist(db.executesql("Select "+s+" from Link"))
            plt.xlabel('Value')
            plt.ylabel('Number')
        elif typeplot == 'sub' :
            for idx,item in enumerate(s.split(',')) :
                plt.subplot(len(s.split(',')),1,idx+1)
                plt.plot(db.executesql("Select "+item+" from Link"))
                plt.ylabel(item+' (Value)')
            plt.xlabel('Number')
        else :
            plt.xlabel('Number')
            plt.ylabel('Value')
            plt.plot(db.executesql("Select "+s+" from Link"))
        plt.title('Plot of Link with '+s)
        plt.savefig('applications/TEMPLATE/static/foo.png')
        plt.clf()
        plot=IMG(_src=URL('static','foo.png'),_alt='plot')
    records=SQLFORM.grid(table,paginate=10,maxtextlength=256,showbuttontext=False)
    return dict(form=form, plot=plot, records=records)
def initData():
    from subprocess import check_call
    try:
        subprocess.check_call(["python","/home/tanguyl/Documents/projetPython/web2py/excel2web2py/scriptInit.py","/home/tanguyl/Documents/projetPython/web2py/excel2web2py/Inventaireproduitschimiques.xlsx"])
    except subprocess.CalledProcessError:
        sys.exit("Error : scriptInit.py could not be reached")