# -*- coding: utf-8 -*-
import sys,subprocess,os,sqlite3,exceptions
# this file is released under public domain and you can use without limitations
#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

#requires login
 
#Delete file from uploads and undo insert into db.excel
#I:name file and name file after upload
#O:None
def deleteUploadedFile(oldName,newName):
    #remove from excel
    db = DAL('sqlite://storage.sqlite')
    db.define_table('excel',Field('fileoname', unique=True),Field('file','upload'))
    excel=db.excel
    db(excel.fileoname == oldName).delete()
    db.close()
    #remove from uploads
    path=os.path.abspath(os.path.dirname(__file__))
    filePath=path+"/../uploads/"+newName
    try:
        if os.name=="nt":
            print filePath.replace('/','\\')
            subprocess.check_call(["DEL","/Q",filePath.replace('/','\\')],shell=True)
        else:
            subprocess.check_call(["rm","-f",filePath])     
    except subprocess.CalledProcessError as er:
        print er.message
    
#Generate a form that will upload a file.
#Test if this file's name is already into db.excel
#Test if excel2web2py folder exists
#Execute script.py with the uploaded file
#Test if errors happened
#Execute the new generated db_Model to generate tables
#Execute scriptInit.py with the uploaded file
#Display appropriate message in flash
#I:None
#O:None
def display_form():
    db = DAL('sqlite://storage.sqlite')
    db.define_table('excel',Field('fileoname', unique=True),Field('file','upload'))
    excel=db.excel
    record = excel(request.args(0)) #or redirect(URL('index'))
    url = URL('download')
    form = SQLFORM(excel, record, deletable=True,
    upload=url, fields=['file'])
    if ((request.vars.file != "") and (request.vars.file != None)):
        form.vars.fileoname = request.vars.file.filename
    res=False
    try:
        res=form.process().accepted
        db.close()
    except (sqlite3.IntegrityError,exceptions.ValueError) as er:
        db.close()
        print er.message
        deleteUploadedFile(form.vars.fileoname,form.vars.file)
        res=False
    
    if res:
        oldName = form.vars.fileoname
        newName = form.vars.file #important when a file is uploaded, he takes a new name, this is it
        session.messageError = 'form accepted'
        path=os.path.abspath(os.path.dirname(__file__))
        filePath=path+"/../uploads/"+newName
        listFolders=[f for f in os.listdir(path+"/../../../") if os.path.isdir(f)]       
        nameFolderScript=""
        for f in listFolders:
            if "excel2web2py" in f:
                nameFolderScript=f
        if nameFolderScript == "":
            print ("No excel2web2py folder")
            session.messageError = "500 : internal error"
        elif os.path.isfile(filePath) :
            from subprocess import check_call
            cmd = []
            if os.name=="nt":
                cmd = ["python",path+"\\..\\..\\..\\"+nameFolderScript+"\\script.py",filePath.replace('/','\\'),oldName]
            else:
                cmd = ["python",path+"/../../../"+nameFolderScript+"/script.py",filePath,oldName]   
            output = subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            msg=output.stderr.read()
            if os.name=="nt":
			    output.communicate()

            if msg != "":
                print msg
                print path+"\\..\\..\\..\\"+nameFolderScript+"\\script.py"
                print filePath.replace('/','\\')
                session.messageError = msg
                deleteUploadedFile(oldName,newName)
                redirect(URL('default','index'))
            try:
                #defineTables should have been written in the new model, let's call it
                dbCode = open(path+'/../models/db_'+oldName.split('.')[0]+'.py').read()
                exec dbCode
            except exceptions.IOError as er:
                print er.message
                deleteUploadedFile(oldName,newName)
                session.messageError = er.message
                redirect(URL('default','index'))
            #Tables have been created, let's fill them all
            print "python",path+"/../../../"+nameFolderScript+"/scriptInit.py"
            print filePath
            try:
                subprocess.check_call(["python",path+"/../../../"+nameFolderScript+"/scriptInit.py",filePath])
            except subprocess.CalledProcessError as er:
                print (er.message)
                response.flash = er.message
                #deleteUploadedFile(oldName,newName)
        #refresh page and menu
        response.flash = session.messageError
        redirect(URL('default','index'))
    elif ((session.messageError != None) and (session.messageError != "")):
        response.flash = session.messageError
        session.messageError = None
    elif((form.vars.fileoname is "")or(form.vars.fileoname is None)):
        response.flash = 'No file selected'
    else:
        response.flash = "form has errors, rename the file or check the readme"

    return form

def index():  
    return dict(form=display_form())

def readme():
    return response.render()

def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
def forming(table):
    form = SQLFORM(table)
    if form.process().accepted:
        response.falsh = 'form accepted'
    elif form.errors:
        response.flash = 'form has errors'
    return form
