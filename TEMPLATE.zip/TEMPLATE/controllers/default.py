# -*- coding: utf-8 -*-
import sys,subprocess,os,sqlite3,exceptions
# this file is released under public domain and you can use without limitations
#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

#requires login
 
#Delete file from uploads and undo insert into db.excel
#I:name file and name file after upload
#O:None
def deleteUploadedFile(excel,oldName,newName):
    #remove from excel
    db = DAL('sqlite://storage.sqlite',auto_import=True)
    db(db.excel.fileoname == oldName).delete()
    db.close()
    #remove from uploads
    path=os.path.abspath(os.path.dirname(__file__))
    filePath=path+"/../uploads/"+newName
    try:
        if os.name=="nt":
            print filePath.replace('/','\\')
            subprocess.check_call(["DEL","/Q",filePath.replace('/','\\')],shell=True)
        else:
            subprocess.check_call(["rm","-f",filePath])     
    except subprocess.CalledProcessError as er:
        print er.message

def deleteUploadedImage(oldName,newName):
    #remove from uploadedImages
    #dbref(dbref.UploadedImages.imageoname == oldName).delete()
    #remove from static/UploadedImages
    path=os.path.abspath(os.path.dirname(__file__))
    filePath=path+"/../static/UploadedImages/"+newName
    try:
        if os.name=="nt":
            print filePath.replace('/','\\')
            subprocess.check_call(["DEL","/Q",filePath.replace('/','\\')],shell=True)
        else:
            subprocess.check_call(["rm","-f",filePath])     
    except subprocess.CalledProcessError as er:
        print er.message
		
#Generate a form that will upload a file.
#Test if this file's name is already into db.excel
#Test if excel2web2py folder exists
#Execute script.py with the uploaded file
#Test if errors happened
#Execute the new generated db_Model to generate tables
#Execute scriptInit.py with the uploaded file
#Display appropriate message in flash
#I:None
#O:None
def display_form():
    db = DAL('sqlite://storage.sqlite')
    db.define_table('excel',Field('fileoname', unique=True),Field('file','upload'))
    excel=db.excel
    record = excel(request.args(0)) #or redirect(URL('index'))
    url = URL('download')
    form = SQLFORM(excel, record, deletable=True,
    upload=url, fields=['file'])
    form.vars.fileoname = ""
    res=False
    if ((request.vars.file != "") and (request.vars.file != None) and ((request.vars.file.filename.endswith(".xlsx"))or(request.vars.file.filename.endswith(".xls")))):
        form.vars.fileoname = request.vars.file.filename
        try:
            res=form.process().accepted
            db.close()
        except (sqlite3.IntegrityError,exceptions.ValueError) as er:
            db.close()
            print er.message
            deleteUploadedFile(excel,form.vars.fileoname,form.vars.file)
            res=False
    if res:
        oldName = form.vars.fileoname
        newName = form.vars.file #important when a file is uploaded, he takes a new name, this is it
        session.messageError = 'form accepted'
        path=os.path.abspath(os.path.dirname(__file__))
        filePath=path+"/../uploads/"+newName
        listFolders=[f for f in os.listdir(path+"/../../../") if os.path.isdir(f)]       
        nameFolderScript=""
        for f in listFolders:
            if "excel2web2py" in f:
                nameFolderScript=f
        if nameFolderScript == "":
            print ("No excel2web2py folder")
            session.messageError = "500 : internal error"
        elif os.path.isfile(filePath) :
            from subprocess import check_call
            cmd = []
            outpout = ""
            if os.name=="nt":
                cmd = ["python",path+"\\..\\..\\..\\"+nameFolderScript+"\\script.py",filePath.replace('/','\\'),oldName]
                output = subprocess.Popen(cmd,stderr=subprocess.PIPE,shell=True)
            else:
                cmd = ["python",path+"/../../../"+nameFolderScript+"/script.py",filePath,oldName]   
                output = subprocess.Popen(cmd,stderr=subprocess.PIPE)
            msg=output.stderr.read()
            if msg != "":
                #try again once, windows can throw false errors
                if os.name=="nt":
                    cmd = ["python",path+"\\..\\..\\..\\"+nameFolderScript+"\\script.py",filePath.replace('/','\\'),oldName]
                    output = subprocess.Popen(cmd,stderr=subprocess.PIPE,shell=True)
                else:
                    cmd = ["python",path+"/../../../"+nameFolderScript+"/script.py",filePath,oldName]   
                    output = subprocess.Popen(cmd,stderr=subprocess.PIPE)
                msg=output.stderr.read()
                if msg != "":
                    print msg
                    print path+"\\..\\..\\..\\"+nameFolderScript+"\\script.py"
                    print filePath.replace('/','\\')
                    session.messageError = msg
                    deleteUploadedFile(excel,oldName,newName)
                    redirect(URL('default','index'))
            try:
                #defineTables should have been written in the new model, let's call it
                dbCode = open(path+'/../models/db_'+oldName.split('.')[0]+'.py').read()
                exec dbCode
            except exceptions.IOError as er:
                print er.message
                deleteUploadedFile(excel,oldName,newName)
                session.messageError = er.message
                redirect(URL('default','index'))
            #Tables have been created, let's fill them all
            print "python",path+"/../../../"+nameFolderScript+"/scriptInit.py"
            print filePath
            try:
                subprocess.check_call(["python",path+"/../../../"+nameFolderScript+"/scriptInit.py",filePath])
            except subprocess.CalledProcessError as er:
                print (er.message)
                response.flash = er.message
                #deleteUploadedFile(oldName,newName)
        #refresh page and menu
        response.flash = session.messageError
        redirect(URL('default','index'))
    elif ((session.messageError != None) and (session.messageError != "")):
        response.flash = session.messageError
        session.messageError = None
    elif((form.vars.fileoname is "")or(form.vars.fileoname is None)):
        response.flash = 'No file selected'
    else:
        response.flash = "form has errors, rename the file or check the readme"

    return form
#Upload image
def display_formI():
    db = DAL('sqlite://storage.sqlite')
    db.define_table('UploadedImages',Field('imageoname', unique=True),Field('Image','upload',uploadfolder=os.path.join(request.folder,'static/UploadedImages')))
    uploadedImages=db.UploadedImages
    record = uploadedImages(request.args(0)) #or redirect(URL('index'))
    url = URL('download')
    formI = SQLFORM(uploadedImages, record, deletable=True,
    upload=url, fields=['Image'])
    formI.vars.imageoname = ""
    res=False
    if ((request.vars.Image != "") and (request.vars.Image != None) and ((request.vars.file.filename.endswith(".png"))or(request.vars.file.filename.endswith(".jpeg")))):
        formI.vars.imageoname = request.vars.Image.filename   
        try:
            res=formI.process().accepted
            db.close()
        except (sqlite3.IntegrityError,exceptions.ValueError) as er:
            db.close()
            print er.message
            deleteUploadedImage(formI.vars.imageoname,formI.vars.Image )
            res=False
    
    if res:
        response.flash+=' ; Image accepted'
    elif ((request.vars.Image == None) or (request.vars.Image == "")) :
        response.flash+=' ; No Image selected'	
    else:
        response.flash+=' ; Image error'	 
    return formI
def index():  
    return dict(form=display_form(),formI=display_formI())

def readme():
    return response.render()

def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    print request
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
def forming(table):
    form = SQLFORM(table)
    if form.process().accepted:
        response.falsh = 'form accepted'
    elif form.errors:
        response.flash = 'form has errors'
    return form
