# -*- coding: utf-8 -*-
import sys,subprocess,os
# this file is released under public domain and you can use without limitations
#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

#requires login
#to do: when does form finish with table ? then db select 
def display_form():
    db = DAL('sqlite://storage.sqlite')
    for t in db.tables:
	    db[t].drop()
    db.define_table('excel',Field('fileoname'),Field('file','upload')) 
    record = db.excel(request.args(0)) #or redirect(URL('index'))
    url = URL('download')
    form = SQLFORM(db.excel, record, deletable=True,
                   upload=url, fields=['file'])
    if request.vars.file!=None:
        form.vars.fileoname = request.vars.file.filename
    if form.process().accepted:
        oldName = form.vars.fileoname
        newName = form.vars.file #important when a file is uploaded, he takes a new name, this is it
        session.flash = 'form accepted'
        path=os.path.abspath(os.path.dirname(__file__))
        filePath=path+"/../uploads/"+newName
        listFolders=[f for f in os.listdir(path+"/../../../") if os.path.isdir(f)]
        nameFolderScript=""
        for f in listFolders:
            if "excel2web2py" in f:
                nameFolderScript=f
        if nameFolderScript == "":
            print ("No excel2web2py folder")
        elif os.path.isfile(filePath) :
            from subprocess import check_call
            try:
                subprocess.check_call(["python",path+"/../../../"+nameFolderScript+"/script.py",filePath,oldName])
            except subprocess.CalledProcessError as er:
                print (er.message)
			#refresh menu
            redirect(URL('default','index'))
    elif form.errors:
        response.flash = 'form has errors'
    return form

def index():
    db = DAL('sqlite://storage.sqlite')
    db.define_table('excel',Field('fileoname'),Field('file','upload'))    
    return dict(form=display_form())

def readme():
    return response.render()

def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
def forming(table):
    form = SQLFORM(table)
    if form.process().accepted:
        response.falsh = 'form accepted'
    elif form.errors:
        response.flash = 'form has errors'
    return form

